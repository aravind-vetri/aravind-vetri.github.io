
console.log("Portfolio loaded");
